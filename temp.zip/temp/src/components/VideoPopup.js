import React from 'react';
import ReactPlayer from 'react-player';
import { useDispatch, useSelector } from 'react-redux';
import { setVideoURL } from '../redux/reducers/dataReducer';
import { useNavigate } from 'react-router-dom';

const VideoPopup = () => {
  const dispatch = useDispatch();
  const videoURL = useSelector((state) => state.dataReducer.videoURL);
  const navigate = useNavigate();
  console.log(videoURL);
  
  return (
    <>
      {videoURL?
        <div className='h-screen w-screen flex flex-col items-center justify-center bg-black'>
          <button className='text-white absolute top-2 right-2 text-xl' 
            onClick={() => {dispatch(setVideoURL('')); navigate(-1)}}> 
            Close
          </button>
          <ReactPlayer url={`https://youtube.com/watch?v=${videoURL}`} playing={true} controls width="90vw" height="90vh"/>
        </div>
        :null
        }
    </>
  )
}

export default VideoPopup;

